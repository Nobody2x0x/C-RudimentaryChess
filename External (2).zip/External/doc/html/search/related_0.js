var searchData=
[
  ['datachannel_0',['DataChannel',['../classsf_1_1Ftp.html#a8dee57337b6a7e183bfe21d178757b0c',1,'sf::Ftp']]],
  ['degrees_1',['degrees',['../classsf_1_1Angle.html#a97d979192b0069419fec49a8135f137b',1,'sf::Angle']]]
];
