var searchData=
[
  ['zoom_0',['zoom',['../classsf_1_1View.html#a4a72a360a5792fbe4e99cd6feaf7726e',1,'sf::View']]]
];
