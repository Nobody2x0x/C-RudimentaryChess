var searchData=
[
  ['http_0',['Http',['../classsf_1_1Http_1_1Request.html#aba95e2a7762bb5df986048b05d03a22e',1,'sf::Http::Request::Http'],['../classsf_1_1Http_1_1Response.html#aba95e2a7762bb5df986048b05d03a22e',1,'sf::Http::Response::Http']]]
];
